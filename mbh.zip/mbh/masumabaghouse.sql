-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2023 at 02:32 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `masumabaghouse`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` bigint(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'moyez', 'moyez');

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add admin', 7, 'add_admin'),
(26, 'Can change admin', 7, 'change_admin'),
(27, 'Can delete admin', 7, 'delete_admin'),
(28, 'Can view admin', 7, 'view_admin'),
(29, 'Can add bag type', 8, 'add_bagtype'),
(30, 'Can change bag type', 8, 'change_bagtype'),
(31, 'Can delete bag type', 8, 'delete_bagtype'),
(32, 'Can view bag type', 8, 'view_bagtype'),
(33, 'Can add catagory', 9, 'add_catagory'),
(34, 'Can change catagory', 9, 'change_catagory'),
(35, 'Can delete catagory', 9, 'delete_catagory'),
(36, 'Can view catagory', 9, 'view_catagory'),
(37, 'Can add city', 10, 'add_city'),
(38, 'Can change city', 10, 'change_city'),
(39, 'Can delete city', 10, 'delete_city'),
(40, 'Can view city', 10, 'view_city'),
(41, 'Can add contact', 11, 'add_contact'),
(42, 'Can change contact', 11, 'change_contact'),
(43, 'Can delete contact', 11, 'delete_contact'),
(44, 'Can view contact', 11, 'view_contact'),
(45, 'Can add cost', 12, 'add_cost'),
(46, 'Can change cost', 12, 'change_cost'),
(47, 'Can delete cost', 12, 'delete_cost'),
(48, 'Can view cost', 12, 'view_cost'),
(49, 'Can add country', 13, 'add_country'),
(50, 'Can change country', 13, 'change_country'),
(51, 'Can delete country', 13, 'delete_country'),
(52, 'Can view country', 13, 'view_country'),
(53, 'Can add customer', 14, 'add_customer'),
(54, 'Can change customer', 14, 'change_customer'),
(55, 'Can delete customer', 14, 'delete_customer'),
(56, 'Can view customer', 14, 'view_customer'),
(57, 'Can add employe', 15, 'add_employe'),
(58, 'Can change employe', 15, 'change_employe'),
(59, 'Can delete employe', 15, 'delete_employe'),
(60, 'Can view employe', 15, 'view_employe'),
(61, 'Can add investment refarence', 16, 'add_investmentrefarence'),
(62, 'Can change investment refarence', 16, 'change_investmentrefarence'),
(63, 'Can delete investment refarence', 16, 'delete_investmentrefarence'),
(64, 'Can view investment refarence', 16, 'view_investmentrefarence'),
(65, 'Can add job sector', 17, 'add_jobsector'),
(66, 'Can change job sector', 17, 'change_jobsector'),
(67, 'Can delete job sector', 17, 'delete_jobsector'),
(68, 'Can view job sector', 17, 'view_jobsector'),
(69, 'Can add route', 18, 'add_route'),
(70, 'Can change route', 18, 'change_route'),
(71, 'Can delete route', 18, 'delete_route'),
(72, 'Can view route', 18, 'view_route'),
(73, 'Can add stock price', 19, 'add_stockprice'),
(74, 'Can change stock price', 19, 'change_stockprice'),
(75, 'Can delete stock price', 19, 'delete_stockprice'),
(76, 'Can view stock price', 19, 'view_stockprice'),
(77, 'Can add vendor', 20, 'add_vendor'),
(78, 'Can change vendor', 20, 'change_vendor'),
(79, 'Can delete vendor', 20, 'delete_vendor'),
(80, 'Can view vendor', 20, 'view_vendor'),
(81, 'Can add stock', 21, 'add_stock'),
(82, 'Can change stock', 21, 'change_stock'),
(83, 'Can delete stock', 21, 'delete_stock'),
(84, 'Can view stock', 21, 'view_stock'),
(85, 'Can add salary', 22, 'add_salary'),
(86, 'Can change salary', 22, 'change_salary'),
(87, 'Can delete salary', 22, 'delete_salary'),
(88, 'Can view salary', 22, 'view_salary'),
(89, 'Can add order memo', 23, 'add_ordermemo'),
(90, 'Can change order memo', 23, 'change_ordermemo'),
(91, 'Can delete order memo', 23, 'delete_ordermemo'),
(92, 'Can view order memo', 23, 'view_ordermemo'),
(93, 'Can add member', 24, 'add_member'),
(94, 'Can change member', 24, 'change_member'),
(95, 'Can delete member', 24, 'delete_member'),
(96, 'Can view member', 24, 'view_member'),
(97, 'Can add investment', 25, 'add_investment'),
(98, 'Can change investment', 25, 'change_investment'),
(99, 'Can delete investment', 25, 'delete_investment'),
(100, 'Can view investment', 25, 'view_investment'),
(101, 'Can add cash memo', 26, 'add_cashmemo'),
(102, 'Can change cash memo', 26, 'change_cashmemo'),
(103, 'Can delete cash memo', 26, 'delete_cashmemo'),
(104, 'Can view cash memo', 26, 'view_cashmemo'),
(105, 'Can add buy', 27, 'add_buy'),
(106, 'Can change buy', 27, 'change_buy'),
(107, 'Can delete buy', 27, 'delete_buy'),
(108, 'Can view buy', 27, 'view_buy');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$390000$mrniouid9U9DfIFW7JLLP1$YaSAU+nPDdWMtLg9VxGFGBwSlkgl40TngrQoQ20pPqg=', '2023-07-26 05:00:04.123824', 1, 'moyez', '', '', 'moyez.swe@gmail.com', 1, 1, '2023-07-15 16:41:16.948268');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bagtype`
--

CREATE TABLE `bagtype` (
  `id` bigint(20) NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bagtype`
--

INSERT INTO `bagtype` (`id`, `name`) VALUES
(7, '60 GSM Folding'),
(3, '60 GSM Printed Bag'),
(6, '60 GSM Small'),
(9, '70 GSM Medium'),
(1, '70 GSM Printed Bag'),
(4, '80 GSM 10/10'),
(5, '80 GSM 14/16'),
(2, '80 GSM Bag'),
(8, '80 GSM Medium');

-- --------------------------------------------------------

--
-- Table structure for table `cashmemo`
--

CREATE TABLE `cashmemo` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `total` double NOT NULL,
  `paid` double NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `route_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cashmemo`
--

INSERT INTO `cashmemo` (`id`, `created`, `total`, `paid`, `customer_id`, `route_id`) VALUES
(3, '2023-07-04', 4300, 3000, 4, 8),
(4, '2022-01-01', 10200, 5000, 2, 5),
(5, '2022-02-01', 10200, 5000, 2, 5),
(6, '2022-03-01', 10200, 5000, 2, 5),
(7, '2022-04-01', 10200, 5000, 2, 5),
(8, '2022-05-01', 10200, 5000, 2, 5),
(9, '2022-06-01', 10200, 5000, 2, 5),
(10, '2022-07-01', 1200, 500, 2, 5),
(11, '2022-08-01', 10200, 2000, 3, 7),
(12, '2022-09-01', 5000, 4000, 4, 8),
(13, '2022-10-01', 4000, 3000, 6, 9),
(14, '2022-11-01', 20000, 10000, 7, 2),
(15, '2022-12-01', 10000, 8000, 8, 4),
(16, '2022-01-01', 4000, 3000, 9, 6),
(17, '2022-02-01', 2000, 1500, 10, 1),
(18, '2022-03-01', 100, 500, 1, 5),
(19, '2022-05-01', 3000, 2000, 5, 3),
(20, '2023-01-01', 10200, 2000, 3, 7),
(21, '2023-02-01', 5000, 4000, 4, 8),
(22, '2023-03-01', 4000, 3000, 6, 9),
(23, '2023-04-01', 20000, 10000, 7, 2),
(24, '2023-05-01', 10000, 8000, 8, 4),
(25, '2023-06-01', 4000, 3000, 9, 6),
(26, '2023-02-01', 2000, 1500, 10, 1),
(27, '2023-03-01', 100, 500, 1, 5),
(28, '2023-05-01', 3000, 2000, 5, 3),
(30, '2023-07-05', 1100, 500, 1, 5),
(31, '2023-07-05', 1050, 600, 5, 3),
(32, '2023-07-05', 2100, 1500, 3, 7),
(33, '2023-07-05', 900, 800, 4, 8),
(34, '2023-07-05', 4300, 3000, 10, 1),
(35, '2023-07-05', 3000, 2000, 5, 3),
(36, '2023-07-05', 1600, 1000, 6, 9),
(37, '2023-07-05', 4300, 3000, 9, 6),
(38, '2023-07-05', 3000, 2500, 11, 1),
(39, '2022-01-10', 30300, 20000, 1, 5),
(40, '2022-02-10', 30300, 20000, 4, 8),
(41, '2022-03-10', 30300, 22000, 3, 7),
(42, '2022-04-10', 30300, 25000, 9, 6),
(43, '2022-05-10', 30300, 26000, 9, 6),
(44, '2022-06-10', 20300, 15000, 8, 4),
(45, '2022-07-10', 40300, 25000, 8, 4),
(46, '2022-08-10', 30300, 20000, 5, 3),
(47, '2022-09-10', 40300, 32000, 5, 3),
(48, '2022-10-10', 40300, 35000, 6, 9),
(49, '2022-11-10', 10300, 8000, 10, 1),
(50, '2022-12-10', 20300, 20000, 11, 1),
(51, '2023-02-10', 30300, 20000, 4, 8),
(52, '2023-03-10', 30300, 22000, 3, 7),
(53, '2023-04-10', 30300, 25000, 9, 6),
(54, '2023-05-10', 30300, 26000, 9, 6),
(55, '2023-06-10', 20300, 15000, 8, 4),
(56, '2023-01-10', 40300, 25000, 8, 4),
(57, '2022-01-15', 30300, 20000, 4, 8),
(58, '2022-02-15', 30300, 20000, 4, 8),
(59, '2022-03-15', 30300, 22000, 3, 7),
(60, '2022-04-15', 30300, 25000, 6, 9),
(61, '2022-05-15', 30300, 26000, 6, 9),
(62, '2022-06-15', 20300, 15000, 8, 4),
(63, '2022-07-15', 40300, 25000, 10, 1),
(64, '2022-08-15', 30300, 20000, 5, 3),
(65, '2022-09-15', 40300, 32000, 5, 3),
(66, '2022-10-15', 40300, 35000, 6, 9),
(67, '2022-11-15', 10300, 8000, 10, 1),
(68, '2022-12-15', 20300, 20000, 11, 1),
(69, '2023-02-15', 30300, 20000, 4, 8),
(70, '2023-03-15', 30300, 22000, 3, 7),
(71, '2023-04-15', 30300, 25000, 9, 6),
(72, '2023-05-15', 30300, 26000, 9, 6),
(73, '2023-06-15', 20300, 15000, 7, 2),
(74, '2023-01-15', 40300, 25000, 3, 7),
(75, '2023-07-05', 15300, 15000, 7, 2),
(76, '2023-07-06', 5300, 2000, 7, 2),
(77, '2023-07-16', 24300, 24000, 1, 5),
(78, '2023-07-16', 10300, 5000, 6, 9),
(79, '2023-07-16', 4000, 3500, 4, 8),
(80, '2023-07-16', 24300, 15000, 2, 5),
(81, '2023-07-16', 8300, 5000, 9, 6),
(82, '2023-07-17', 5000, 3000, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `catagory`
--

CREATE TABLE `catagory` (
  `id` bigint(20) NOT NULL,
  `catagory` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `catagory`
--

INSERT INTO `catagory` (`id`, `catagory`) VALUES
(1, 'Plate'),
(3, '80 GSM Lot'),
(4, '60 GSM Lot'),
(5, '70 GSM Lot');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(254) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE `cost` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `description` varchar(80) NOT NULL,
  `cost` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`id`, `created`, `description`, `cost`) VALUES
(1, '2023-07-05', 'Tea Bill', 100),
(2, '2023-07-05', 'Breakfast Bill', 50),
(3, '2023-07-05', 'Nasta', 100);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `shop_name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `route_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `phone_number`, `shop_name`, `address`, `route_id`) VALUES
(1, 'Moyez', '01714967039', 'MU Fashion', 'Tremohoni Bazar', 5),
(2, 'Baten', '017343243234', 'RB Fashion', 'Kansat Bazar', 5),
(3, 'Rajib', '01734323412', 'ICC Communication', 'Boro Indara', 7),
(4, 'Simran Khan', '01654527365', 'Niha Cosmetics', 'Kholshi', 8),
(5, 'Afrail Hossain', '01765432678', 'AH Garments', 'Nawgaun Bazar', 3),
(6, 'Sofiullah', '01754342312', 'SA Garments', 'Niamotpur Bazar', 9),
(7, 'Bihon', '01734324321', 'Bihon Offset', 'Khoharmor', 2),
(8, 'Rashed', '01710876754', 'Rashidul E.Prise', 'Bus Stand', 4),
(9, 'Rana', '01825735461', 'RanaFisha', 'Shibganj Bazar', 6),
(10, 'Shohidul Islam', '01734726378', 'SH Garments', 'Volahat Bazar', 1),
(11, 'Alom Khan', '018654321', 'Alam Farmecy', 'Volahat Bazar', 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'masumabaghouse', 'admin'),
(8, 'masumabaghouse', 'bagtype'),
(27, 'masumabaghouse', 'buy'),
(26, 'masumabaghouse', 'cashmemo'),
(9, 'masumabaghouse', 'catagory'),
(10, 'masumabaghouse', 'city'),
(11, 'masumabaghouse', 'contact'),
(12, 'masumabaghouse', 'cost'),
(13, 'masumabaghouse', 'country'),
(14, 'masumabaghouse', 'customer'),
(15, 'masumabaghouse', 'employe'),
(25, 'masumabaghouse', 'investment'),
(16, 'masumabaghouse', 'investmentrefarence'),
(17, 'masumabaghouse', 'jobsector'),
(24, 'masumabaghouse', 'member'),
(23, 'masumabaghouse', 'ordermemo'),
(18, 'masumabaghouse', 'route'),
(22, 'masumabaghouse', 'salary'),
(21, 'masumabaghouse', 'stock'),
(19, 'masumabaghouse', 'stockprice'),
(20, 'masumabaghouse', 'vendor'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2023-07-04 15:48:39.658303'),
(2, 'auth', '0001_initial', '2023-07-04 15:48:49.285051'),
(3, 'admin', '0001_initial', '2023-07-04 15:48:52.619634'),
(4, 'admin', '0002_logentry_remove_auto_add', '2023-07-04 15:48:52.730475'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2023-07-04 15:48:52.816862'),
(6, 'contenttypes', '0002_remove_content_type_name', '2023-07-04 15:48:53.707785'),
(7, 'auth', '0002_alter_permission_name_max_length', '2023-07-04 15:48:54.518267'),
(8, 'auth', '0003_alter_user_email_max_length', '2023-07-04 15:48:54.652757'),
(9, 'auth', '0004_alter_user_username_opts', '2023-07-04 15:48:54.681825'),
(10, 'auth', '0005_alter_user_last_login_null', '2023-07-04 15:48:55.931428'),
(11, 'auth', '0006_require_contenttypes_0002', '2023-07-04 15:48:55.953104'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2023-07-04 15:48:55.985171'),
(13, 'auth', '0008_alter_user_username_max_length', '2023-07-04 15:48:56.286730'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2023-07-04 15:48:56.386269'),
(15, 'auth', '0010_alter_group_name_max_length', '2023-07-04 15:48:56.586391'),
(16, 'auth', '0011_update_proxy_permissions', '2023-07-04 15:48:56.631281'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2023-07-04 15:48:56.719331'),
(18, 'masumabaghouse', '0001_initial', '2023-07-04 15:49:22.254442'),
(19, 'sessions', '0001_initial', '2023-07-04 15:49:24.057757'),
(20, 'masumabaghouse', '0002_buy_total', '2023-07-04 16:46:25.238453');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('lawpn50u6uuct4vk14web8grocvz2691', '.eJxVjMsOwiAQRf-FtSHDs-DSvd9ABgakaiAp7cr479qkC93ec859sYDbWsM28hJmYmcm2Ol3i5geue2A7thunafe1mWOfFf4QQe_dsrPy-H-HVQc9Vu7pCgZyOiljBEdgERhbEnKCeUMgLLSTbIoC8poIuEjRG-01zhZQ4W9P8bvNtQ:1qLOQB:IOYsY88_QtqPB_NRU0zsuDPo9mEuXW4MclqGfrO0938', '2023-07-31 13:37:51.369869');

-- --------------------------------------------------------

--
-- Table structure for table `employe`
--

CREATE TABLE `employe` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `address` varchar(80) NOT NULL,
  `salary` double NOT NULL,
  `nid` varchar(100) NOT NULL,
  `job_sector_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employe`
--

INSERT INTO `employe` (`id`, `name`, `phone_number`, `address`, `salary`, `nid`, `job_sector_id`) VALUES
(1, 'Osman Gani', '01734324355', 'Rohanpur', 50000, 'images/343539218_1187752521911476_7437211921873847992_n.jpg', 1),
(2, 'Eva Islam', '01734324321', 'Rohanpur', 40000, 'images/343706481_205946905648678_2598808469566741105_n.jpg', 2),
(4, 'Kamal Hossain', '01734324366', 'Rohanpur', 15000, 'images/345119890_1604867666682141_1624495565439526732_n.jpg', 3),
(5, 'Moyez Uddin', '01734224355', 'Kansat', 20000, 'images/345119890_1604867666682141_1624495565439526732_n_KY5wAUG.jpg', 7),
(6, 'Selim Reza', '01734324125', 'Kholshi', 12000, 'images/343756057_642482420693275_6089234815615569588_n.jpg', 4),
(7, 'Simran Khan', '01734323455', 'Kholshi', 12000, 'images/343294380_799769408078195_5317698500006821161_n.jpg', 6),
(8, 'Kasem Ali', '01710876736', 'Rohanpur', 10000, 'images/343756057_642482420693275_6089234815615569588_n_lZroten.jpg', 8),
(9, 'Nira Hassan', '01822345461', 'Rohanpur', 9000, 'images/343706481_205946905648678_2598808469566741105_n_0Sh09VG.jpg', 9),
(10, 'Amena Begum', '01756438765', 'Rohanpur', 9000, 'images/343756057_642482420693275_6089234815615569588_n_9USF6BX.jpg', 9);

-- --------------------------------------------------------

--
-- Table structure for table `investment`
--

CREATE TABLE `investment` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `investment` double NOT NULL,
  `investmentrefarence_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investment`
--

INSERT INTO `investment` (`id`, `created`, `investment`, `investmentrefarence_id`) VALUES
(1, '2023-07-05', 200000, 1),
(2, '2023-07-05', 50000, 2),
(3, '2023-07-05', 80000, 4),
(4, '2023-07-05', 35000, 3),
(5, '2023-07-05', 50000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `investmentrefarence`
--

CREATE TABLE `investmentrefarence` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `investmentrefarence`
--

INSERT INTO `investmentrefarence` (`id`, `name`) VALUES
(1, 'Bank'),
(3, 'By Manager'),
(4, 'By Product'),
(2, 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `jobsector`
--

CREATE TABLE `jobsector` (
  `id` bigint(20) NOT NULL,
  `job_sector` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobsector`
--

INSERT INTO `jobsector` (`id`, `job_sector`) VALUES
(1, 'Owner'),
(2, 'Chaiman'),
(3, 'Manager'),
(4, 'Marketing'),
(5, 'Employe'),
(6, 'Route Collection'),
(7, 'Designer'),
(8, 'Cutting'),
(9, 'Selai');

-- --------------------------------------------------------

--
-- Table structure for table `masumabaghouse_buy`
--

CREATE TABLE `masumabaghouse_buy` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `quantity` double NOT NULL,
  `price` double NOT NULL,
  `catagory_id` bigint(20) NOT NULL,
  `vendor_id` bigint(20) NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `masumabaghouse_buy`
--

INSERT INTO `masumabaghouse_buy` (`id`, `created`, `quantity`, `price`, `catagory_id`, `vendor_id`, `total`) VALUES
(1, '2023-07-04', 5, 250, 1, 1, 1250),
(2, '2023-07-04', 2, 30000, 3, 1, 60000),
(3, '2023-07-04', 2, 25000, 4, 1, 50000),
(4, '2023-07-04', 3, 28000, 5, 1, 84000);

-- --------------------------------------------------------

--
-- Table structure for table `masumabaghouse_city`
--

CREATE TABLE `masumabaghouse_city` (
  `id` bigint(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `country_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `masumabaghouse_country`
--

CREATE TABLE `masumabaghouse_country` (
  `id` bigint(20) NOT NULL,
  `name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `masumabaghouse_member`
--

CREATE TABLE `masumabaghouse_member` (
  `id` bigint(20) NOT NULL,
  `name` varchar(124) NOT NULL,
  `email` varchar(125) NOT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  `country_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `masumabaghouse_salary`
--

CREATE TABLE `masumabaghouse_salary` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `salary` double NOT NULL,
  `e_id_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `masumabaghouse_salary`
--

INSERT INTO `masumabaghouse_salary` (`id`, `created`, `salary`, `e_id_id`) VALUES
(1, '2023-06-10', 50000, 1),
(2, '2023-06-10', 40000, 2),
(3, '2023-06-10', 9000, 9),
(4, '2023-06-10', 9000, 10),
(5, '2023-06-10', 20000, 5),
(6, '2023-06-10', 10000, 6),
(7, '2023-06-10', 12000, 7),
(8, '2023-06-10', 15000, 4),
(9, '2023-07-05', 9000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ordermemo`
--

CREATE TABLE `ordermemo` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `quantity` double NOT NULL,
  `rate` double NOT NULL,
  `sub_total` double NOT NULL,
  `plate` double NOT NULL,
  `total` double NOT NULL,
  `paid` double NOT NULL,
  `bag_type_id` bigint(20) NOT NULL,
  `customer_id` bigint(20) NOT NULL,
  `route_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ordermemo`
--

INSERT INTO `ordermemo` (`id`, `created`, `quantity`, `rate`, `sub_total`, `plate`, `total`, `paid`, `bag_type_id`, `customer_id`, `route_id`) VALUES
(3, '2023-07-04', 500, 8, 4000, 300, 4300, 3000, 3, 4, 8),
(4, '2022-01-01', 1000, 10, 10000, 200, 10200, 5000, 1, 2, 5),
(5, '2022-02-01', 1000, 10, 10000, 200, 10200, 5000, 1, 2, 5),
(6, '2022-03-01', 1000, 10, 10000, 200, 10200, 5000, 1, 2, 5),
(7, '2022-04-01', 1000, 10, 10000, 200, 10200, 5000, 1, 2, 5),
(8, '2022-05-01', 1000, 10, 10000, 200, 10200, 5000, 1, 2, 5),
(9, '2022-06-01', 1000, 10, 10000, 200, 10200, 5000, 1, 2, 5),
(10, '2022-07-01', 1000, 10, 1000, 200, 1200, 500, 1, 2, 5),
(12, '2022-08-01', 1200, 10, 12000, 200, 10200, 2000, 5, 3, 7),
(13, '2022-09-01', 500, 10, 5000, 0, 5000, 4000, 4, 4, 8),
(14, '2022-10-01', 500, 8, 4000, 0, 4000, 3000, 7, 6, 9),
(15, '2022-11-01', 2000, 10, 20000, 0, 20000, 10000, 8, 7, 2),
(16, '2022-12-01', 1000, 10, 10000, 0, 10000, 8000, 9, 8, 4),
(17, '2022-01-01', 400, 10, 4000, 0, 4000, 3000, 4, 9, 6),
(18, '2022-02-01', 200, 10, 2000, 0, 2000, 1500, 1, 10, 1),
(19, '2022-03-01', 100, 10, 1000, 0, 1000, 500, 2, 1, 5),
(20, '2022-05-01', 300, 10, 3000, 0, 3000, 2000, 3, 5, 3),
(21, '2023-01-01', 1200, 10, 12000, 200, 10200, 2000, 5, 3, 7),
(22, '2023-02-01', 500, 10, 5000, 0, 5000, 4000, 4, 4, 8),
(23, '2023-03-01', 500, 8, 4000, 0, 4000, 3000, 7, 6, 9),
(24, '2023-04-01', 2000, 10, 20000, 0, 20000, 10000, 8, 7, 2),
(25, '2023-05-01', 1000, 10, 10000, 0, 10000, 8000, 9, 8, 4),
(26, '2023-06-01', 400, 10, 4000, 0, 4000, 3000, 4, 9, 6),
(27, '2023-02-01', 200, 10, 2000, 0, 2000, 1500, 1, 10, 1),
(28, '2023-03-01', 100, 10, 1000, 0, 1000, 500, 2, 1, 5),
(29, '2023-05-01', 300, 10, 3000, 0, 3000, 2000, 3, 5, 3),
(31, '2023-07-05', 100, 8, 800, 300, 1100, 500, 1, 1, 5),
(32, '2023-07-05', 150, 7, 1050, 0, 1050, 600, 3, 5, 3),
(33, '2023-07-05', 200, 9, 1800, 300, 2100, 1500, 7, 3, 7),
(34, '2023-07-05', 120, 7.5, 900, 0, 900, 800, 9, 4, 8),
(35, '2023-07-05', 500, 8, 4000, 300, 4300, 3000, 7, 10, 1),
(36, '2023-07-05', 300, 9, 2700, 300, 3000, 2000, 6, 5, 3),
(37, '2023-07-05', 100, 13, 1300, 300, 1600, 1000, 4, 6, 9),
(38, '2023-07-05', 500, 8, 4000, 300, 4300, 3000, 3, 9, 6),
(39, '2023-07-05', 300, 10, 3000, 0, 3000, 2500, 2, 11, 1),
(40, '2022-01-10', 3000, 10, 30000, 300, 30300, 20000, 1, 1, 5),
(41, '2022-02-10', 3000, 10, 30000, 300, 30300, 20000, 1, 4, 8),
(42, '2022-03-10', 3000, 10, 30000, 300, 30300, 22000, 2, 3, 7),
(43, '2022-04-10', 3000, 10, 30000, 300, 30300, 25000, 3, 9, 6),
(44, '2022-05-10', 3000, 10, 30000, 300, 30300, 26000, 4, 9, 6),
(45, '2022-06-10', 2000, 10, 20000, 300, 20300, 15000, 5, 8, 4),
(46, '2022-07-10', 4000, 10, 40000, 300, 40300, 25000, 6, 8, 4),
(47, '2022-08-10', 3000, 10, 30000, 300, 30300, 20000, 7, 5, 3),
(48, '2022-09-10', 4000, 10, 40000, 300, 40300, 32000, 8, 5, 3),
(49, '2022-10-10', 4000, 10, 40000, 300, 40300, 35000, 9, 6, 9),
(50, '2022-11-10', 1000, 10, 10000, 300, 10300, 8000, 1, 10, 1),
(51, '2022-12-10', 2000, 10, 20000, 300, 20300, 20000, 2, 11, 1),
(52, '2023-02-10', 3000, 10, 30000, 300, 30300, 20000, 1, 4, 8),
(53, '2023-03-10', 3000, 10, 30000, 300, 30300, 22000, 2, 3, 7),
(54, '2023-04-10', 3000, 10, 30000, 300, 30300, 25000, 3, 9, 6),
(55, '2023-05-10', 3000, 10, 30000, 300, 30300, 26000, 4, 9, 6),
(56, '2023-06-10', 2000, 10, 20000, 300, 20300, 15000, 5, 8, 4),
(57, '2023-01-10', 4000, 10, 40000, 300, 40300, 25000, 6, 8, 4),
(58, '2022-01-15', 3000, 10, 30000, 300, 30300, 20000, 1, 4, 8),
(59, '2022-02-15', 3000, 10, 30000, 300, 30300, 20000, 1, 4, 8),
(60, '2022-03-15', 3000, 10, 30000, 300, 30300, 22000, 2, 3, 7),
(61, '2022-04-15', 3000, 10, 30000, 300, 30300, 25000, 3, 6, 9),
(62, '2022-05-15', 3000, 10, 30000, 300, 30300, 26000, 4, 6, 9),
(63, '2022-06-15', 2000, 10, 20000, 300, 20300, 15000, 5, 8, 4),
(64, '2022-07-15', 4000, 10, 40000, 300, 40300, 25000, 6, 10, 1),
(65, '2022-08-15', 3000, 10, 30000, 300, 30300, 20000, 7, 5, 3),
(66, '2022-09-15', 4000, 10, 40000, 300, 40300, 32000, 8, 5, 3),
(67, '2022-10-15', 4000, 10, 40000, 300, 40300, 35000, 9, 6, 9),
(68, '2022-11-15', 1000, 10, 10000, 300, 10300, 8000, 1, 10, 1),
(69, '2022-12-15', 2000, 10, 20000, 300, 20300, 20000, 2, 11, 1),
(70, '2023-02-15', 3000, 10, 30000, 300, 30300, 20000, 1, 4, 8),
(71, '2023-03-15', 3000, 10, 30000, 300, 30300, 22000, 2, 3, 7),
(72, '2023-04-15', 3000, 10, 30000, 300, 30300, 25000, 3, 9, 6),
(73, '2023-05-15', 3000, 10, 30000, 300, 30300, 26000, 4, 9, 6),
(74, '2023-06-15', 2000, 10, 20000, 300, 20300, 15000, 5, 7, 2),
(75, '2023-01-15', 4000, 10, 40000, 300, 40300, 25000, 6, 3, 7),
(76, '2023-07-05', 1500, 10, 15000, 300, 15300, 15000, 1, 7, 2),
(77, '2023-07-06', 500, 10, 5000, 300, 5300, 2000, 3, 7, 2),
(78, '2023-07-16', 3000, 8, 24000, 300, 24300, 24000, 3, 1, 5),
(79, '2023-07-16', 1000, 10, 10000, 300, 10300, 5000, 6, 6, 9),
(80, '2023-07-16', 500, 8, 4000, 0, 4000, 3500, 7, 4, 8),
(81, '2023-07-16', 3000, 8, 24000, 300, 24300, 15000, 1, 2, 5),
(82, '2023-07-16', 1000, 8, 8000, 300, 8300, 5000, 1, 9, 6),
(83, '2023-07-17', 500, 10, 5000, 0, 5000, 3000, 1, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `id` bigint(20) NOT NULL,
  `route_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`id`, `route_name`) VALUES
(7, 'Chapai'),
(8, 'Gomostapur'),
(5, 'Kansat'),
(3, 'Nawgaun'),
(9, 'Niamotpur'),
(2, 'Rohanpur'),
(4, 'Sapahar'),
(6, 'Shibganj'),
(1, 'Volahat');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` bigint(20) NOT NULL,
  `created` date NOT NULL,
  `quantity` double NOT NULL,
  `bag_type_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `created`, `quantity`, `bag_type_id`) VALUES
(1, '2023-07-04', 62700, 1),
(2, '2023-07-04', 72022, 2),
(3, '2023-07-04', 72350, 3),
(4, '2023-07-04', 59900, 7),
(5, '2023-07-04', 40876, 6),
(6, '2023-07-04', 47156, 9),
(7, '2023-07-04', 42022, 8),
(8, '2023-07-04', 50222, 5),
(9, '2023-07-04', 42880, 4);

-- --------------------------------------------------------

--
-- Table structure for table `stockprice`
--

CREATE TABLE `stockprice` (
  `id` bigint(20) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `company_name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`id`, `name`, `phone_number`, `company_name`, `address`) VALUES
(1, 'Moyez', '01734324321', 'China Import Center', 'Kansat'),
(2, 'Abdul Korim', '01967543214', 'CIC Co Ltd', 'Farmegate, Dhaka'),
(3, 'Kamrul Hassan', '01825732461', 'SntBD co Limited', 'Uttara-10, Dhaka'),
(4, 'Rashedul Islam', '01654785643', 'Rasidul Enterprise', 'Kansat'),
(5, 'Rahim Islam', '01876543276', 'Rahim Group', 'Gulisthan, Dhaka'),
(6, 'Selim Reza', '01754876655', 'SR Bag Suplier', 'Savar, Dhaka'),
(7, 'Foyshal Islam', '01865432678', 'FI Bag Supplier', 'Asuliya, Savar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `bagtype`
--
ALTER TABLE `bagtype`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `cashmemo`
--
ALTER TABLE `cashmemo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cashMemo_customer_id_9e9b09c6_fk_customer_id` (`customer_id`),
  ADD KEY `cashMemo_route_id_74a67a16_fk_route_id` (`route_id`);

--
-- Indexes for table `catagory`
--
ALTER TABLE `catagory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cost`
--
ALTER TABLE `cost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`),
  ADD KEY `customer_route_id_19b6162b_fk_route_id` (`route_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `employe`
--
ALTER TABLE `employe`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`),
  ADD KEY `employe_job_sector_id_34da9191_fk_jobsector_id` (`job_sector_id`);

--
-- Indexes for table `investment`
--
ALTER TABLE `investment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `investment_investmentrefarence__cf7d8e45_fk_investmen` (`investmentrefarence_id`);

--
-- Indexes for table `investmentrefarence`
--
ALTER TABLE `investmentrefarence`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `jobsector`
--
ALTER TABLE `jobsector`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masumabaghouse_buy`
--
ALTER TABLE `masumabaghouse_buy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masumabaghouse_buy_catagory_id_17e2e1c5_fk_catagory_id` (`catagory_id`),
  ADD KEY `masumabaghouse_buy_vendor_id_1b74897b_fk_vendor_id` (`vendor_id`);

--
-- Indexes for table `masumabaghouse_city`
--
ALTER TABLE `masumabaghouse_city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masumabaghouse_city_country_id_96b3c435_fk_masumabag` (`country_id`);

--
-- Indexes for table `masumabaghouse_country`
--
ALTER TABLE `masumabaghouse_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `masumabaghouse_member`
--
ALTER TABLE `masumabaghouse_member`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masumabaghouse_member_city_id_d9b46d01_fk_masumabaghouse_city_id` (`city_id`),
  ADD KEY `masumabaghouse_membe_country_id_7a50e6d3_fk_masumabag` (`country_id`);

--
-- Indexes for table `masumabaghouse_salary`
--
ALTER TABLE `masumabaghouse_salary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `masumabaghouse_salary_e_id_id_3d478b11_fk_employe_id` (`e_id_id`);

--
-- Indexes for table `ordermemo`
--
ALTER TABLE `ordermemo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderMemo_bag_type_id_51d6411e_fk_stock_id` (`bag_type_id`),
  ADD KEY `orderMemo_customer_id_ecdb95e0_fk_customer_id` (`customer_id`),
  ADD KEY `orderMemo_route_id_368642bf_fk_route_id` (`route_id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `route_name` (`route_name`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stock_bag_type_id_4ff2b5bb_fk_bagtype_id` (`bag_type_id`);

--
-- Indexes for table `stockprice`
--
ALTER TABLE `stockprice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone_number` (`phone_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bagtype`
--
ALTER TABLE `bagtype`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `cashmemo`
--
ALTER TABLE `cashmemo`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `catagory`
--
ALTER TABLE `catagory`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cost`
--
ALTER TABLE `cost`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `employe`
--
ALTER TABLE `employe`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `investment`
--
ALTER TABLE `investment`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `investmentrefarence`
--
ALTER TABLE `investmentrefarence`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobsector`
--
ALTER TABLE `jobsector`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `masumabaghouse_buy`
--
ALTER TABLE `masumabaghouse_buy`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `masumabaghouse_city`
--
ALTER TABLE `masumabaghouse_city`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `masumabaghouse_country`
--
ALTER TABLE `masumabaghouse_country`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `masumabaghouse_member`
--
ALTER TABLE `masumabaghouse_member`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `masumabaghouse_salary`
--
ALTER TABLE `masumabaghouse_salary`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ordermemo`
--
ALTER TABLE `ordermemo`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `route`
--
ALTER TABLE `route`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `stockprice`
--
ALTER TABLE `stockprice`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vendor`
--
ALTER TABLE `vendor`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `cashmemo`
--
ALTER TABLE `cashmemo`
  ADD CONSTRAINT `cashMemo_customer_id_9e9b09c6_fk_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `cashMemo_route_id_74a67a16_fk_route_id` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`);

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_route_id_19b6162b_fk_route_id` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `employe`
--
ALTER TABLE `employe`
  ADD CONSTRAINT `employe_job_sector_id_34da9191_fk_jobsector_id` FOREIGN KEY (`job_sector_id`) REFERENCES `jobsector` (`id`);

--
-- Constraints for table `investment`
--
ALTER TABLE `investment`
  ADD CONSTRAINT `investment_investmentrefarence__cf7d8e45_fk_investmen` FOREIGN KEY (`investmentrefarence_id`) REFERENCES `investmentrefarence` (`id`);

--
-- Constraints for table `masumabaghouse_buy`
--
ALTER TABLE `masumabaghouse_buy`
  ADD CONSTRAINT `masumabaghouse_buy_catagory_id_17e2e1c5_fk_catagory_id` FOREIGN KEY (`catagory_id`) REFERENCES `catagory` (`id`),
  ADD CONSTRAINT `masumabaghouse_buy_vendor_id_1b74897b_fk_vendor_id` FOREIGN KEY (`vendor_id`) REFERENCES `vendor` (`id`);

--
-- Constraints for table `masumabaghouse_city`
--
ALTER TABLE `masumabaghouse_city`
  ADD CONSTRAINT `masumabaghouse_city_country_id_96b3c435_fk_masumabag` FOREIGN KEY (`country_id`) REFERENCES `masumabaghouse_country` (`id`);

--
-- Constraints for table `masumabaghouse_member`
--
ALTER TABLE `masumabaghouse_member`
  ADD CONSTRAINT `masumabaghouse_membe_country_id_7a50e6d3_fk_masumabag` FOREIGN KEY (`country_id`) REFERENCES `masumabaghouse_country` (`id`),
  ADD CONSTRAINT `masumabaghouse_member_city_id_d9b46d01_fk_masumabaghouse_city_id` FOREIGN KEY (`city_id`) REFERENCES `masumabaghouse_city` (`id`);

--
-- Constraints for table `masumabaghouse_salary`
--
ALTER TABLE `masumabaghouse_salary`
  ADD CONSTRAINT `masumabaghouse_salary_e_id_id_3d478b11_fk_employe_id` FOREIGN KEY (`e_id_id`) REFERENCES `employe` (`id`);

--
-- Constraints for table `ordermemo`
--
ALTER TABLE `ordermemo`
  ADD CONSTRAINT `orderMemo_bag_type_id_51d6411e_fk_stock_id` FOREIGN KEY (`bag_type_id`) REFERENCES `stock` (`id`),
  ADD CONSTRAINT `orderMemo_customer_id_ecdb95e0_fk_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `orderMemo_route_id_368642bf_fk_route_id` FOREIGN KEY (`route_id`) REFERENCES `route` (`id`);

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_bag_type_id_4ff2b5bb_fk_bagtype_id` FOREIGN KEY (`bag_type_id`) REFERENCES `bagtype` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
