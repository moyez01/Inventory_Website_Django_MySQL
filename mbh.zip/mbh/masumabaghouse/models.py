"""
high level support for doing this and that.
"""
from django.db import models

class Admin(models.Model):
    username = models.CharField(max_length=30, unique=True)
    password = models.CharField(max_length=50)
    class Meta:
        db_table = 'admin'
        
class Route(models.Model):
    route_name = models.CharField(max_length=50, unique=True)
    class Meta:
        db_table = 'route'
    def __str__(self):
        return self.route_name

class Customer(models.Model):
    name = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=20, unique=True)
    shop_name = models.CharField(max_length=60)
    address = models.CharField(max_length=80)
    route = models.ForeignKey(Route, blank=True, null=True, on_delete=models.CASCADE)
    class Meta:
        db_table = 'customer'
    def __str__(self):
        return self.name + ' : ' + self.shop_name

class Vendor(models.Model):
    name = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=20, unique=True)
    company_name = models.CharField(max_length=60)
    address = models.CharField(max_length=80)
    class Meta:
        db_table = 'vendor'
    def __str__(self):
        return self.name

class JobSector(models.Model):
    job_sector = models.CharField(max_length=50)
    class Meta:
        db_table = 'jobsector'
    def __str__(self):
        return self.job_sector

class Employe(models.Model):
    #join_date = models.DateField()
    name = models.CharField(max_length=50)
    job_sector = models.ForeignKey(JobSector, default=1, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=20, unique=True)
    address = models.CharField(max_length=80)
    salary = models.FloatField()
    nid = models.ImageField(upload_to='images', default="")
    class Meta:
        db_table = 'employe'
    def __str__(self):
        return self.name

class BagType(models.Model):
    name = models.CharField(max_length=60, unique=True)
    class Meta:
        db_table = 'bagtype'
    def __str__(self):
        return self.name

class Stock(models.Model):
    created = models.DateField(auto_now_add=True)
    bag_type = models.ForeignKey(BagType, default=1, on_delete=models.CASCADE)
    quantity = models.FloatField()
    class Meta:
        db_table = 'stock'
    def __str__(self):
        #return str(self.bag_type)
        return str(self.bag_type) + ' : ' + str(self.quantity)

class OrderMemo(models.Model):
    created = models.DateField(auto_now_add=True)
    bag_type = models.ForeignKey(Stock, default=1, on_delete=models.CASCADE)
    quantity = models.FloatField()
    rate = models.FloatField()
    sub_total = models.FloatField()
    plate = models.FloatField()
    total = models.FloatField()
    paid = models.FloatField()
    route = models.ForeignKey(Route, default=1, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, default=1, on_delete=models.CASCADE)
    class Meta:
        db_table = 'orderMemo'

class CashMemo(models.Model):
    created = models.DateField(auto_now_add=True)
    route =  models.ForeignKey(Route, default=1, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, default=1, on_delete=models.CASCADE)
    total = models.FloatField(blank=True)
    paid = models.FloatField()
    class Meta:
        db_table = 'cashMemo'
    def __str__(self):
        return self.customer.name

class Catagory(models.Model):
    catagory = models.CharField(max_length=80)
    class Meta:
        db_table = 'catagory'
    def __str__(self):
        return self.catagory

class Buy(models.Model):
    created = models.DateField(auto_now_add=True)
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE)
    catagory = models.ForeignKey(Catagory, on_delete=models.CASCADE)
    quantity = models.FloatField()
    price = models.FloatField()
    total = models.FloatField()
    def __str__(self):
        return self.catagory

class Salary(models.Model):
    created = models.DateField(auto_now_add=True)
    salary = models.FloatField()
    e_id = models.ForeignKey(Employe, default=1, on_delete=models.CASCADE, related_name='employe')

class Cost(models.Model):
    created = models.DateField(auto_now_add=True)
    description =  models.CharField(max_length=80)
    cost = models.FloatField()
    class Meta:
        db_table = 'cost'

class InvestmentRefarence(models.Model):
    name = models.CharField(max_length=50, unique=True)
    class Meta:
        db_table = 'investmentrefarence'
    def __str__(self):
        return self.name

class Investment(models.Model):
    created = models.DateField(auto_now_add=True)
    investmentrefarence = models.ForeignKey(InvestmentRefarence, default=1, on_delete=models.CASCADE)
    investment = models.FloatField()
    class Meta:
        db_table = 'investment'
    def __str__(self):
        return self.investment

class StockPrice(models.Model):
    price = models.FloatField()
    class Meta:
        db_table = 'stockprice'
    def __str__(self):
        return self.price

class Contact(models.Model):
    created = models.DateField(auto_now_add=True)
    name = models.CharField(max_length=50)
    email = models.EmailField()
    subject = models.CharField(max_length=100)
    message = models.CharField(max_length=500)
    class Meta:
        db_table = 'contact'

class Country(models.Model):
    name = models.CharField(max_length=40)
 
    def __str__(self):
        return self.name
 
class City(models.Model):
    country = models.ForeignKey(Country, on_delete=models.CASCADE)
    name = models.CharField(max_length=40)
 
    def __str__(self):
        return self.name
 
class Member(models.Model):
    name = models.CharField(max_length=124)
    email = models.CharField(max_length=125)
    country = models.ForeignKey(Country, on_delete=models.SET_NULL, blank=True, null=True)
    city = models.ForeignKey(City, on_delete=models.SET_NULL, blank=True, null=True)
 
    def __str__(self):
        return self.name