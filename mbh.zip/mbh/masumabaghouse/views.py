"""
high level support for doing this and that.
"""
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.shortcuts import render, redirect
from masumabaghouse.models import  Route, Customer, Vendor, Employe, BagType, OrderMemo, CashMemo, Salary, Cost, Catagory, Buy, InvestmentRefarence, Investment, Stock, JobSector, StockPrice, Admin
from masumabaghouse.forms import AdminLoginForm, RouteForm, CustomerForm, VendorForm, EmployeForm, BagTypeForm, OrderMemoForm, CashMemoForm, SalaryForm, CostForm, CatagoryForm, BuyForm, InvestmentRefarenceForm, InvestmentForm, StockForm, JobSectorForm, StockPriceForm
import datetime, os
from django.db.models import Sum, Count, Avg
from json import dumps

    
@login_required
def index(request):
    route_count = Route.objects.all().count()
    customer_count=Customer.objects.all().count()
    employe_count=Employe.objects.all().count()
    vendor_count=Vendor.objects.all().count()
    
    order_count=OrderMemo.objects.all().count()
    ordermemos = OrderMemo.objects.all()
    total__sum = ordermemos.aggregate(total_order=Sum('total'))['total_order']
    paid__sum = ordermemos.aggregate(total_paid=Sum('paid'))['total_paid']
    try:
        due__sum = total__sum - paid__sum
    except:
        due__sum = 0
    try:
        paid__sum_percent = (paid__sum / total__sum) * 100
        due__sum_percent = (due__sum / total__sum) *100
    except:
        paid__sum_percent = 0
        due__sum_percent = 0

    present_day = datetime.date.today()
    daily_collection = CashMemo.objects.filter(created=present_day).aggregate(daily_collection = Sum('paid'))['daily_collection']
    daily_cost = Cost.objects.filter(created=present_day).aggregate(daily_cost = Sum('cost'))['daily_cost']
    daily_salary = Salary.objects.filter(created=present_day).aggregate(daily_salary = Sum('salary'))['daily_salary']
    daily_cost_salary = int(0 if daily_cost is None else daily_cost) + int(0 if daily_salary is None else daily_salary)
    daily_cash =  int(0 if daily_collection is None else daily_collection) - int(0 if daily_cost_salary is None else daily_cost_salary)

    ordermemo_present_day = OrderMemo.objects.filter(created=present_day).count
    order_sum_present_day = OrderMemo.objects.filter(created=present_day).aggregate(Sum('paid'))['paid__sum']
    plate_total = OrderMemo.objects.filter(created=present_day, plate__gt = 0)
    plate_total_count = plate_total.count
    plate_total_sum = plate_total.aggregate(Sum('plate'))['plate__sum']

    customer_total_paid = OrderMemo.objects.values('customer__name').order_by('customer').annotate(total=Sum('total')).annotate(paid=Sum('paid'))[:5]
    '''customer_list = OrderMemo.objects.prefetch_related('customer').order_by('customer')[:5]
    cash_total = OrderMemo.objects.values('customer').order_by('customer').annotate(total_price=Sum('total'))[:5]
    cash_paid = OrderMemo.objects.values('customer').order_by('customer').annotate(total_paid=Sum('paid'))[:5]
    customer_total_paid_dues = []
    for i in range(0, len(cash_total)):
        temp =[]
        temp.append(customer_list[i])
        temp.append(cash_total[i]['total_price'])
        temp.append(cash_paid[i]['total_paid'])
        temp.append(format((cash_total[i]['total_price'] - cash_paid[i]['total_paid']) / cash_total[i]['total_price'] * 100, '.2f'))
        customer_total_paid_dues.append(temp)'''
    #customer_total_paid_dues = sorted(customer_total_paid_dues, key=lambda x: x[3], reverse=True)

    route_total = OrderMemo.objects.values('route__route_name').order_by('route').annotate(total_price=Sum('total')) 
    route_name_list=[]
    route_price_list = []
    for i in range(0, len(route_total)):
        route_name_list.append(route_total[i]['route__route_name'])
        route_price_list.append(route_total[i]['total_price'])
            
    present_year = datetime.date.today().year
    present_year_monthly_sell = []
    last_year = present_year - 1 
    last_year_monthly_sell = []
    for i in range(1, 13):
        ordermemo_present_year = OrderMemo.objects.filter(created__year=present_year, created__month=i)
        ordermemo_last_year = OrderMemo.objects.filter(created__year=last_year, created__month=i)
        if not ordermemo_present_year:
            present_year_monthly_sell.append(0)
        else:
            monthly_total__sum = ordermemo_present_year.aggregate(Sum('total'))['total__sum']
            present_year_monthly_sell.append(monthly_total__sum)
        if not ordermemo_last_year:
            last_year_monthly_sell.append(0)
        else:
            last_year_monthly_total__sum = ordermemo_last_year.aggregate(Sum('total'))['total__sum']
            last_year_monthly_sell.append(last_year_monthly_total__sum)
    
    present_day_time = datetime.datetime.now()
    daily_bag_type_order = OrderMemo.objects.filter(created=present_day).values('bag_type__bag_type__name').order_by('bag_type').annotate(total_quantity=Sum('quantity')).annotate(avg_rate=Avg('rate')).annotate(total_rate=Sum('sub_total'))  
    daily_route_order = OrderMemo.objects.filter(created=present_day).values('route__route_name').order_by('route').annotate(bag_order=Sum('sub_total')).annotate(plate_order=Sum('plate'))

    return render(request, 'dark-index.html',{'route_count':route_count, 'customer_count':customer_count, 'employe_count':employe_count, 'vendor_count':vendor_count,
    'order_count':order_count,
    'total__sum':total__sum, 'present_year_monthly_sell':present_year_monthly_sell, 'last_year_monthly_sell':last_year_monthly_sell, 'paid__sum_percent':paid__sum_percent,
    'due__sum_percent':due__sum_percent, 'route_name_list':route_name_list, 'route_price_list':route_price_list, 'route_total':len(route_total), 'paid__sum':paid__sum, 'due__sum':due__sum,
    'daily_collection':daily_collection, 'daily_cost_salary':daily_cost_salary, 'daily_cash':daily_cash,
    'ordermemo_present_day': ordermemo_present_day, 'order_sum_present_day':order_sum_present_day, 'present_day_time':present_day_time,
    'customer_total_paid':customer_total_paid, 'plate_total_count':plate_total_count,
    'plate_total_sum':plate_total_sum, 'daily_bag_type_order':daily_bag_type_order,'daily_route_order':daily_route_order})

@login_required
def AddRoute(request):
    if request.method == "POST":
        form=RouteForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewroute')
            except:
                pass
    form=RouteForm()
    return render(request, 'addroute.html', {'form' : form})
@login_required
def ViewRoute(request):
    routes = Route.objects.all()
    return render(request, 'viewroute.html', {'routes':routes})
@login_required
def DeleteRoute(request, id):
    route = Route.objects.get(id=id)
    route.delete()
    return redirect('/viewroute')
@login_required
def EditRoute(request, id):
    route = Route.objects.get(pk=id)
    form=RouteForm(instance=route)
    return render(request, 'editroute.html', {'route':route, 'form':form})
@login_required
def UpdateRoute(request, id):
    route = Route.objects.get(id=id)
    form=RouteForm(request.POST, instance=route)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    form=RouteForm()
    return redirect('/viewroute')

@login_required
def AddCustomer(request):
    if request.method == "POST":
        form=CustomerForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewcustomer')
            except:
                pass
    form=CustomerForm()
    return render(request, 'addcustomer.html', {'form' : form})
@login_required
def ViewCustomer(request):
    customers = Customer.objects.all()
    return render(request, 'viewcustomer.html', {'customers':customers})
@login_required
def DeleteCustomer(request, id):
    customer = Customer.objects.get(id=id)
    customer.delete()
    return redirect('/viewcustomer')
@login_required
def EditCustomer(request, id):
    customer = Customer.objects.get(pk=id)
    form=CustomerForm(instance=customer)
    return render(request, 'editcustomer.html', {'customer':customer, 'form':form})
@login_required
def UpdateCustomer(request, id):
    customer = Customer.objects.get(pk=id)
    form=CustomerForm(request.POST, instance=customer)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewcustomer')
@login_required
def AddVendor(request):
    if request.method == "POST":
        form=VendorForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewvendor')
            except:
                pass
    form=VendorForm()
    return render(request, 'addvendor.html', {'form' : form})
@login_required
def ViewVendor(request):
    vendors = Vendor.objects.all()
    return render(request, 'viewvendor.html', {'vendors':vendors})
@login_required
def DeleteVendor(request, id):
    vendor = Vendor.objects.get(id=id)
    vendor.delete()
    return redirect('/viewvendor')
@login_required
def EditVendor(request, id):
    vendor = Vendor.objects.get(pk=id)
    form=VendorForm(instance=vendor)
    return render(request, 'editvendor.html', {'vendor':vendor, 'form':form})
@login_required
def UpdateVendor(request, id):
    vendor = Vendor.objects.get(pk=id)
    form=VendorForm(request.POST, instance=vendor)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewvendor')
@login_required
def AddJobSector(request):
    if request.method == "POST":
        form=JobSectorForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewjobsector')
            except:
                pass
    form=JobSectorForm()
    return render(request, 'addjobsector.html', {'form' : form})
@login_required
def ViewJobSector(request):
    jobsectors = JobSector.objects.all()
    return render(request, 'viewjobsector.html', {'jobsectors':jobsectors})
@login_required
def DeleteJobSector(request, id):
    jobsector = JobSector.objects.get(id=id)
    jobsector.delete()
    return redirect('/viewjobsector')
@login_required
def EditJobSector(request, id):
    jobsector = JobSector.objects.get(id=id)
    return render(request, 'editjobsector.html', {'jobsector':jobsector})
@login_required
def UpdateJobSector(request, id):
    jobsector = JobSector.objects.get(id=id)
    form=JobSectorForm(request.POST, instance=jobsector)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    form=JobSectorForm()
    return redirect('/viewjobsector')
@login_required
def AddEmploye(request):
    if request.method == "POST":
        form=EmployeForm(request.POST or None, request.FILES or None)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewemploye')
            except:
                pass
    form=EmployeForm()
    return render(request, 'addemploye.html', {'form' : form})
@login_required
def EmployeProfile(request, id):
    employe = Employe.objects.get(pk=id)
    return render(request, 'employeprofile.html', {'employe':employe})
@login_required
def ViewEmploye(request):
    employes = Employe.objects.all()
    return render(request, 'viewemploye.html', {'employes':employes})
@login_required
def DeleteEmploye(request, id):
    employe = Employe.objects.get(id=id)
    try:
        if len(employe.nid) > 0:
            os.remove(employe.nid.path)
    except:
        pass
    employe.delete()
    return redirect('/viewemploye')
@login_required
def EditEmploye(request, id):
    employe = Employe.objects.get(pk=id)
    form=EmployeForm(instance=employe)
    return render(request, 'editemploye.html', {'employe':employe, 'form':form})
@login_required
def UpdateEmploye(request, id):
    employe = Employe.objects.get(pk=id)
    form=EmployeForm(request.POST or None, request.FILES or None, instance=employe)
    if request.method == "POST":
        try:
            if employe.nid==request.FILES['nid']:
                pass
            else:
                os.remove(employe.nid.path)
        except:
            pass
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewemploye')
@login_required
def AddBagType(request):
    if request.method == "POST":
        form=BagTypeForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewbagtype')
            except:
                pass
    form=BagTypeForm()
    return render(request, 'addbagtype.html', {'form' : form})
@login_required
def ViewBagType(request):
    bagtypes = BagType.objects.all()
    return render(request, 'viewbagtype.html', {'bagtypes':bagtypes})
@login_required
def DeleteBagType(request, id):
    bagtype = BagType.objects.get(id=id)
    bagtype.delete()
    return redirect('/viewbagtype')
@login_required
def EditBagType(request, id):
    bagtype = BagType.objects.get(id=id)
    return render(request, 'editbagtype.html', {'bagtype':bagtype})
@login_required
def UpdateBagType(request, id):
    bagtype = BagType.objects.get(id=id)
    form=BagTypeForm(request.POST, instance=bagtype)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    form=BagTypeForm()
    return redirect('/viewbagtype')
@login_required
def AddOrderMemo(request):
    if request.method == "POST":
        form=OrderMemoForm(request.POST)
        form1=CashMemoForm(request.POST)
        bag_type_id = request.POST['bag_type']
        quantity = request.POST['quantity']
        '''customer = request.POST['customer']
        total = request.POST['total']
        paid = request.POST['paid']
        due = request.POST['due']
        o_id = request.POST['id']'''
        stock = Stock.objects.get(pk=bag_type_id)
        stock.quantity = stock.quantity - float(quantity)
        if stock.quantity > 0:
            if form.is_valid:
                try:
                    form.save()
                    form1.save()
                    stock.save()
                    return redirect('/viewordermemo')
                except:
                    pass
        else:
            pass
    customer = Customer.objects.all()[:1].get()
    form=OrderMemoForm(initial={'route': customer.route, 'customer':  customer})
    return render(request, 'addordermemo.html', {'form' : form})
@login_required
def ViewOrderMemo(request):
    ordermemos = OrderMemo.objects.all()
    quantity__sum = ordermemos.aggregate(Sum('quantity'))['quantity__sum']
    sub_total__sum = ordermemos.aggregate(Sum('sub_total'))['sub_total__sum']
    plate__sum = ordermemos.aggregate(Sum('plate'))['plate__sum']
    total__sum = ordermemos.aggregate(Sum('total'))['total__sum']
    paid__sum = ordermemos.aggregate(Sum('paid'))['paid__sum']
    try:
        due__sum = total__sum - paid__sum
    except:
        due__sum = 0
    return render(request, 'viewordermemo.html', {'ordermemos':ordermemos, 'total__sum':total__sum, 
    'paid__sum':paid__sum, 'due__sum':due__sum, 'quantity__sum':quantity__sum, 'sub_total__sum':sub_total__sum,
    'plate__sum':plate__sum})
@login_required
def DeleteOrderMemo(request, id):
    ordermemo = OrderMemo.objects.get(id=id)
    ordermemo.delete()
    return redirect('/viewordermemo')
@login_required
def EditOrderMemo(request, id):
    ordermemo = OrderMemo.objects.get(pk=id)
    form=OrderMemoForm(instance=ordermemo)
    return render(request, 'editordermemo.html', {'ordermemo':ordermemo, 'form':form})
@login_required
def UpdateOrderMemo(request, id):
    ordermemo = OrderMemo.objects.get(pk=id)
    form=OrderMemoForm(request.POST, instance=ordermemo)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewordermemo')
@login_required
def AddCashMemo(request):
    if request.method == "POST":
        form=CashMemoForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewcashmemo')
            except:
                pass
    customer = Customer.objects.all()[:1].get()
    form=CashMemoForm(initial={'route': customer.route, 'customer':  customer})
    return render(request, 'addcashmemo.html', {'form' : form})
@login_required
def ViewCashMemo(request):
    cashmemos = CashMemo.objects.all()
    return render(request, 'viewcashmemo.html', {'cashmemos':cashmemos})
@login_required
def DeleteCashMemo(request, id):
    cashmemo = CashMemo.objects.get(id=id)
    cashmemo.delete()
    return redirect('/viewcashmemo')
@login_required
def EditCashMemo(request, id):
    cashmemo = CashMemo.objects.get(pk=id)
    form=CashMemoForm(instance=cashmemo)
    return render(request, 'editcashmemo.html', {'cashmemo':cashmemo, 'form':form})
@login_required
def UpdateCashMemo(request, id):
    cashmemo = CashMemo.objects.get(pk=id)
    form=CashMemoForm(request.POST, instance=cashmemo)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewcashmemo')
@login_required
def AddSalary(request):
    if request.method == "POST":
        form=SalaryForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewsalary')
            except:
                pass
    form=SalaryForm()
    return render(request, 'addsalary.html', {'form' : form})
@login_required
def ViewSalary(request):
    salarys = Salary.objects.all()
    return render(request, 'viewsalary.html', {'salarys':salarys})
@login_required
def DeleteSalary(request, id):
    salary = Salary.objects.get(id=id)
    salary.delete()
    return redirect('/viewsalary')
@login_required
def EditSalary(request, id):
    salary = Salary.objects.get(pk=id)
    form=SalaryForm(instance=salary)
    return render(request, 'editsalary.html', {'salary':salary, 'form':form})
@login_required
def UpdateSalary(request, id):
    salary = Salary.objects.get(pk=id)
    form=SalaryForm(request.POST, instance=salary)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewsalary')
@login_required
def AddCost(request):
    if request.method == "POST":
        form=CostForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewcost')
            except:
                pass
    form=CostForm()
    return render(request, 'addcost.html', {'form' : form})
@login_required
def ViewCost(request):
    costs = Cost.objects.all()
    return render(request, 'viewcost.html', {'costs':costs})
@login_required
def DeleteCost(request, id):
    cost = Cost.objects.get(id=id)
    cost.delete()
    return redirect('/viewcost')
@login_required
def EditCost(request, id):
    cost = Cost.objects.get(pk=id)
    form=CostForm(instance=cost)
    return render(request, 'editcost.html', {'cost':cost, 'form':form})
@login_required
def UpdateCost(request, id):
    cost = Cost.objects.get(pk=id)
    form=CostForm(request.POST, instance=cost)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewcost')
@login_required
def AddCatagory(request):
    if request.method == "POST":
        form=CatagoryForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewcatagory')
            except:
                pass
    form=CatagoryForm()
    return render(request, 'addcatagory.html', {'form' : form})
@login_required
def ViewCatagory(request):
    catagorys = Catagory.objects.all()
    return render(request, 'viewcatagory.html', {'catagorys':catagorys})
@login_required
def DeleteCatagory(request, id):
    catagory = Catagory.objects.get(id=id)
    catagory.delete()
    return redirect('/viewcatagory')
@login_required
def EditCatagory(request, id):
    catagory = Catagory.objects.get(id=id)
    return render(request, 'editcatagory.html', {'catagory':catagory})
@login_required
def UpdateCatagory(request, id):
    catagory = Catagory.objects.get(id=id)
    form=CatagoryForm(request.POST, instance=catagory)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    form=CatagoryForm()
    return redirect('/viewcatagory')
@login_required
def AddBuy(request):
    if request.method == "POST":
        form=BuyForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewbuy')
            except:
                pass
    form=BuyForm()
    return render(request, 'addbuy.html', {'form' : form})
@login_required
def ViewBuy(request):
    buys = Buy.objects.all()
    return render(request, 'viewbuy.html', {'buys':buys})
@login_required
def DeleteBuy(request, id):
    buy = Buy.objects.get(id=id)
    buy.delete()
    return redirect('/viewbuy')
@login_required
def EditBuy(request, id):
    buy = Buy.objects.get(pk=id)
    form=BuyForm(instance=buy)
    return render(request, 'editbuy.html', {'buy':buy, 'form':form})
@login_required
def UpdateBuy(request, id):
    buy = Buy.objects.get(pk=id)
    form=BuyForm(request.POST, instance=buy)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewcashmemo')
@login_required
def AddInvestmentRefarence(request):
    if request.method == "POST":
        form=InvestmentRefarenceForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewinvestmentrefarence')
            except:
                pass
    form=InvestmentRefarenceForm()
    return render(request, 'addinvestmentrefarence.html', {'form' : form})
@login_required
def ViewInvestmentRefarence(request):
    investmentrefarences = InvestmentRefarence.objects.all()
    return render(request, 'viewinvestmentrefarence.html', {'investmentrefarences':investmentrefarences})
@login_required
def DeleteInvestmentRefarence(request, id):
    investmentrefarence = InvestmentRefarence.objects.get(id=id)
    investmentrefarence.delete()
    return redirect('/viewinvestmentrefarence')
@login_required
def EditInvestmentRefarence(request, id):
    investmentrefarence = InvestmentRefarence.objects.get(id=id)
    return render(request, 'editinvestmentrefarence.html', {'investmentrefarence':investmentrefarence})
@login_required
def UpdateInvestmentRefarence(request, id):
    investmentrefarence = InvestmentRefarence.objects.get(id=id)
    form=InvestmentRefarenceForm(request.POST, instance=investmentrefarence)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    form=InvestmentRefarenceForm()
    return redirect('/viewinvestmentrefarence')
@login_required
def AddInvestment(request):
    if request.method == "POST":
        form=InvestmentForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewinvestment')
            except:
                pass
    form=InvestmentForm()
    return render(request, 'addinvestment.html', {'form' : form})
@login_required
def ViewInvestment(request):
    investments = Investment.objects.all()
    return render(request, 'viewinvestment.html', {'investments':investments})
@login_required
def DeleteInvestment(request, id):
    investment = Investment.objects.get(id=id)
    investment.delete()
    return redirect('/viewinvestment')
@login_required
def EditInvestment(request, id):
    investment = Investment.objects.get(pk=id)
    form=InvestmentForm(instance=investment)
    return render(request, 'editinvestment.html', {'investment':investment, 'form':form})
@login_required
def UpdateInvestment(request, id):
    investment = Investment.objects.get(pk=id)
    form=InvestmentForm(request.POST, instance=investment)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewinvestment')
@login_required
def AddStock(request):
    if request.method == "POST":
        form=StockForm(request.POST)
        try:
            bag_type_id = request.POST['bag_type']
            quantity = request.POST['quantity']
            stock = Stock.objects.get(bag_type=bag_type_id)
            stock.quantity = stock.quantity + float(quantity)
            stock.save()
            return redirect('/viewstock')
        except:
            if form.is_valid:
                try:
                    form.save()
                    return redirect('/viewstock')
                except:
                    pass
    form=StockForm()
    return render(request, 'addstock.html', {'form' : form})
@login_required
def ViewStock(request):
    stocks = Stock.objects.all()
    return render(request, 'viewstock.html', {'stocks':stocks})
@login_required
def DeleteStock(request, id):
    stock = Stock.objects.get(id=id)
    stock.delete()
    return redirect('/viewstock')
@login_required
def EditStock(request, id):
    stock = Stock.objects.get(pk=id)
    form=StockForm(instance=stock)
    return render(request, 'editstock.html', {'stock':stock, 'form':form})
@login_required
def UpdateStock(request, id):
    stock = Stock.objects.get(pk=id)
    form=StockForm(request.POST, instance=stock)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    return redirect('/viewstock')
@login_required
def AddStockPrice(request):
    if request.method == "POST":
        form=StockPriceForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewstockprice')
            except:
                pass
    form=StockPriceForm()
    return render(request, 'addstockprice.html', {'form' : form})
@login_required
def ViewStockPrice(request):
    stockprices = StockPrice.objects.all()
    return render(request, 'viewstockprice.html', {'stockprices':stockprices})
@login_required
def DeleteStockPrice(request, id):
    stockprice = StockPrice.objects.get(id=id)
    stockprice.delete()
    return redirect('/viewstockprice')
@login_required
def EditStockPrice(request, id):
    stockprice = StockPrice.objects.get(id=id)
    return render(request, 'editstockprice.html', {'stockprice':stockprice})
@login_required
def UpdateStockPrice(request, id):
    stockprice = StockPrice.objects.get(id=id)
    form=StockPriceForm(request.POST, instance=stockprice)
    if request.method == "POST":
        if form.is_valid:
            try:
                form.save()
            except:
                pass
    form=StockPriceForm()
    return redirect('/viewstockprice')
@login_required
def ViewCustomerOrder(request, id):
    customer_id = id
    ordermemos = OrderMemo.objects.filter(customer_id=id)
    quantity__sum = ordermemos.aggregate(Sum('quantity'))['quantity__sum']
    sub_total__sum = ordermemos.aggregate(Sum('sub_total'))['sub_total__sum']
    plate__sum = ordermemos.aggregate(Sum('plate'))['plate__sum']
    total__sum = ordermemos.aggregate(Sum('total'))['total__sum']
    paid__sum = ordermemos.aggregate(Sum('paid'))['paid__sum']
    return render(request, 'viewcustomerorder.html', {'ordermemos':ordermemos, 'total__sum':total__sum, 
    'paid__sum':paid__sum, 'quantity__sum':quantity__sum, 'sub_total__sum':sub_total__sum,
    'plate__sum':plate__sum, 'customer_id': customer_id})
@login_required
def ViewCustomerCashmemo(request, id):
    customer_id = id
    cashmemos = CashMemo.objects.filter(customer_id=id)
    total__sum = OrderMemo.objects.filter(customer=id).aggregate(Sum('total'))['total__sum']
    paid__sum = CashMemo.objects.filter(customer=id).aggregate(Sum('paid'))['paid__sum']
    '''total__sum = cashmemos.aggregate(Sum('total'))['total__sum']
    paid__sum = cashmemos.aggregate(Sum('paid'))['paid__sum']'''
    return render(request, 'viewcustomercashmemo.html', {'cashmemos':cashmemos, 'total__sum':total__sum, 
    'paid__sum':paid__sum, 'customer_id':customer_id})
@login_required

def AddCustomerOrderMemo(request, id):
    customer = Customer.objects.get(pk=id)
    if request.method == "POST":
        form=OrderMemoForm(request.POST)
        form1=CashMemoForm(request.POST)
        bag_type_id = request.POST['bag_type']
        quantity = request.POST['quantity']
        stock = Stock.objects.get(pk=bag_type_id)
        stock.quantity = stock.quantity - float(quantity)
        if stock.quantity > 0:
            if form.is_valid:
                try:
                    form.save()
                    form1.save()
                    stock.save()
                    return redirect('/viewordermemo')
                except:
                    pass
        else:
            pass
    form=OrderMemoForm(initial={'route':customer.route, 'customer':customer})
    return render(request, 'addcustomerordermemo.html', {'form' : form})
@login_required
def SaveCustomerOrderMemo(request):
    if request.method == "POST":
        form=OrderMemoForm(request.POST)
        form1=CashMemoForm(request.POST)
        bag_type_id = request.POST['bag_type']
        quantity = request.POST['quantity']
        '''customer = request.POST['customer']
        total = request.POST['total']
        paid = request.POST['paid']
        due = request.POST['due']
        o_id = request.POST['id']'''
        stock = Stock.objects.get(pk=bag_type_id)
        stock.quantity = stock.quantity - float(quantity)
        if stock.quantity > 0:
            if form.is_valid:
                try:
                    form.save()
                    form1.save()
                    stock.save()
                    return redirect('/viewordermemo')
                except:
                    pass
        else:
            pass
@login_required
def AddCustomerCashMemo(request, id):
    customer = Customer.objects.get(pk=id)
    total = OrderMemo.objects.filter(customer=id).aggregate(Sum('total'))['total__sum']
    paid = CashMemo.objects.filter(customer=id).aggregate(Sum('paid'))['paid__sum']
    due = 0
    try:
        due = total - paid
    except:
        due = 0
    if request.method == "POST":
        form=CashMemoForm(request.POST)
        total = request.POST['total']
        paid = request.POST['paid']
        total = total - paid
        form.total = total
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewcashmemo')
            except:
                pass
    form=CashMemoForm(initial={'route':customer.route, 'customer':customer, 'total':due})
    return render(request, 'addcustomercashmemo.html', {'form' : form, 'due':due})
@login_required
def SaveCustomerCashMemo(request):
    if request.method == "POST":
        form=CashMemoForm(request.POST)
        if form.is_valid:
            try:
                form.save()
                return redirect('/viewcashmemo')
            except:
                pass
    '''if request.method == "POST":
        route = request.POST['route']
        customer = request.POST['customer']
        total = request.POST['total']
        paid = request.POST['paid']
        try:
            CashMemo.objects.create(route=route, customer=customer, total=total, paid=paid)
            return redirect('/viewcashmemo')
        except:
            pass'''
@login_required
def ViewTotal(request):
    total__sum = OrderMemo.objects.aggregate(Sum('total'))['total__sum']
    return render(request, 'a.html', {'total__sum' : total__sum})
@login_required
def Analysis(request):
    total__sum = OrderMemo.objects.aggregate(Sum('total'))['total__sum']
    return render(request, 'a.html', {'total__sum' : total__sum})

def error_404_view(request, exception):
	return render(request, '404.html')

# AJAX
def load_customers(request):
    route_id = request.GET.get('route')
    customers = Customer.objects.filter(route_id=route_id).all()
    return render(request, 'customer_dropdown_list_options.html', {'customers': customers})