from django import forms
from masumabaghouse.models import Admin, Route, Customer, Vendor, Employe, BagType, OrderMemo, CashMemo, Salary, Cost, Catagory, Buy, InvestmentRefarence, Investment, Stock, JobSector, StockPrice, Member, City
from django.db.models import Sum

class AdminLoginForm(forms.ModelForm):
    class Meta:
        model=Admin
        fields="__all__"
        widgets={
            'username':forms.TextInput(attrs={'class':'form-control'}),
            'password':forms.TextInput(attrs={'class':'form-control'}),
        }

class RouteForm(forms.ModelForm):
    class Meta:
        model=Route
        fields="__all__"
        widgets={
            'route_name':forms.TextInput(attrs={'class':'form-control'}),
        }  

class CustomerForm(forms.ModelForm):
    class Meta:
        model=Customer
        fields="__all__"
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control','style' : 'margin-bottom : .31cm'}),
            'phone_number':forms.TextInput(attrs={'class':'form-control','style' : 'margin-bottom : .31cm'}),
            'shop_name':forms.TextInput(attrs={'class':'form-control','style' : 'margin-bottom : .31cm'}),
            'address':forms.TextInput(attrs={'class':'form-control','style' : 'margin-bottom : .31cm'}),
            'route':forms.Select(attrs={'class':'form-select'}),
        }
    def __init__(self, *args, **kwargs):
        super(CustomerForm, self).__init__(*args, **kwargs)
        self.fields['route'].empty_label="Select"

class VendorForm(forms.ModelForm):
    class Meta:
        model=Vendor
        fields="__all__"
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'phone_number':forms.TextInput(attrs={'class':'form-control'}),
            'company_name':forms.TextInput(attrs={'class':'form-control'}),
            'address':forms.TextInput(attrs={'class':'form-control'}),
        }

class JobSectorForm(forms.ModelForm):
    class Meta:
        model=JobSector
        fields="__all__"
        widgets={
            'job_sector':forms.TextInput(attrs={'class':'form-control'}),
        }  

class EmployeForm(forms.ModelForm):
    class Meta:
        model=Employe
        fields="__all__"
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'job_sector':forms.Select(attrs={'class':'form-select'}),
            'phone_number':forms.TextInput(attrs={'class':'form-control'}),
            'address':forms.TextInput(attrs={'class':'form-control'}),
            'salary':forms.TextInput(attrs={'class':'form-control', 'style' : 'margin-bottom :.31cm'}),
        }

class BagTypeForm(forms.ModelForm):
    class Meta:
        model=BagType
        fields="__all__"
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control'}),
        }

class OrderMemoForm(forms.ModelForm):
    class Meta:
        model=OrderMemo
        fields="__all__"
        widgets={
            'bag_type':forms.Select(attrs={'class':'form-select', 'onclick':'myFunction()'}),
            'quantity':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'rate':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'sub_total':forms.NumberInput(attrs={'class':'form-control', 'readonly':True}),
            'plate':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'total':forms.NumberInput(attrs={'class':'form-control', 'readonly':True}),
            'paid':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'route': forms.Select(attrs={ 'class': 'form-select' }),
            'customer': forms.Select(attrs={ 'class': 'form-select' }),
        }
    def __init__(self, *args, **kwargs):
        super(OrderMemoForm, self).__init__(*args, **kwargs)
        self.fields['bag_type'].empty_label="Select"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'route' in self.data:
            try:
                route_id = int(self.data.get('route'))
                self.fields['customer'].queryset = Customer.objects.filter(route_id=route_id).order_by('name')
            except (ValueError, TypeError):
                pass  # invalid input from the client; ignore and fallback to empty Customer queryset
        elif self.instance.pk:
            self.fields['customer'].queryset = self.instance.route.customer_set.order_by('name')

class CashMemoForm(forms.ModelForm):
    class Meta:
        model=CashMemo
        fields=['route','customer','total','paid']
        widgets={
            'route':forms.Select(attrs={'class':'form-select'}),
            'customer':forms.Select(attrs={'class':'form-select'}),
            'total':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'paid':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
        }
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if 'route' in self.data:
            try:
                route_id = int(self.data.get('route'))
                self.fields['customer'].queryset = Customer.objects.filter(route_id=route_id).order_by('name')
                '''if 'customer' in self.data:
                    customer = int(self.data.get('customer'))
                    self.fields['total'].queryset = Customer.objects.filter(customer_id=customer).aggregate(Sum('total'))['total__sum']'''
            except (ValueError, TypeError):
                pass  # invalid input from the client; ignore and fallback to empty Customer queryset
        elif self.instance.pk:
            self.fields['customer'].queryset = self.instance.route.customer_set.order_by('name')
        

class SalaryForm(forms.ModelForm):
    class Meta:
        model=Salary
        fields="__all__"
        widgets={
            'salary':forms.NumberInput(attrs={'class':'form-control'}),
            'e_id':forms.Select(attrs={'class':'form-select'}),
        }

class CostForm(forms.ModelForm):
    class Meta:
        model=Cost
        fields="__all__"
        widgets={
            'description':forms.TextInput(attrs={'class':'form-control'}),
            'cost':forms.NumberInput(attrs={'class':'form-control'}),
        }
class CatagoryForm(forms.ModelForm):
    class Meta:
        model=Catagory
        fields="__all__"
        widgets={
            'catagory':forms.TextInput(attrs={'class':'form-control'}),
        }

class BuyForm(forms.ModelForm):
    class Meta:
        model=Buy
        fields="__all__"
        widgets={
            'vendor':forms.Select(attrs={'class':'form-select'}),
            'catagory':forms.Select(attrs={'class':'form-select'}),
            'quantity':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'price':forms.NumberInput(attrs={'class':'form-control', 'onkeyup':'myFunction()'}),
            'total':forms.NumberInput(attrs={'class':'form-control'}),
        }

class InvestmentRefarenceForm(forms.ModelForm):
    class Meta:
        model=InvestmentRefarence
        fields="__all__"
        widgets={
            'name':forms.TextInput(attrs={'class':'form-control'}),
        }  

class InvestmentForm(forms.ModelForm):
    class Meta:
        model=Investment
        fields="__all__"
        widgets={   
            'investmentrefarence':forms.Select(attrs={'class':'form-select'}),
            'investment':forms.NumberInput(attrs={'class':'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super(InvestmentForm, self).__init__(*args, **kwargs)
        self.fields['investmentrefarence'].empty_label="Select"

class StockForm(forms.ModelForm):
    class Meta:
        model=Stock
        fields="__all__"
        widgets={   
            'bag_type':forms.Select(attrs={'class':'form-select'}),
            'quantity':forms.NumberInput(attrs={'class':'form-control'}),
        }
    
class StockPriceForm(forms.ModelForm):
    class Meta:
        model=StockPrice
        fields="__all__"
        widgets={
            'price':forms.NumberInput(attrs={'class':'form-control'}),
        }  

        