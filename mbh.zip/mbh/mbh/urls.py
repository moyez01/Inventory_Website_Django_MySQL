"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from masumabaghouse import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')), 
    path('addroute', views.AddRoute),
    path('viewroute', views.ViewRoute),
    path('deleteroute/<int:id>', views.DeleteRoute),
    path('editroute/<int:id>', views.EditRoute),
    path('updateroute/<int:id>', views.UpdateRoute),

    path('addcustomer', views.AddCustomer),
    path('viewcustomer', views.ViewCustomer),
    path('deletecustomer/<int:id>', views.DeleteCustomer),
    path('editcustomer/<int:id>', views.EditCustomer),
    path('updatecustomer/<int:id>', views.UpdateCustomer),
    path('viewcustomerorder/<int:id>', views.ViewCustomerOrder),
    path('addcustomerordermemo/<int:id>', views.AddCustomerOrderMemo),
    path('savecustomerordermemo', views.SaveCustomerOrderMemo),
    path('viewcustomercashmemo/<int:id>', views.ViewCustomerCashmemo),
    path('addcustomercashmemo/<int:id>', views.AddCustomerCashMemo),
    path('savecustomercashmemo', views.SaveCustomerCashMemo),

    path('addvendor', views.AddVendor),
    path('viewvendor', views.ViewVendor),
    path('deletevendor/<int:id>', views.DeleteVendor),
    path('editvendor/<int:id>', views.EditVendor),
    path('updatevendor/<int:id>', views.UpdateVendor),

    path('addjobsector', views.AddJobSector),
    path('viewjobsector', views.ViewJobSector),
    path('deletejobsector/<int:id>', views.DeleteJobSector),
    path('editjobsector/<int:id>', views.EditJobSector),
    path('updatejobsector/<int:id>', views.UpdateJobSector),

    path('addemploye', views.AddEmploye),
    path('employeprofile/<int:id>', views.EmployeProfile),
    path('viewemploye', views.ViewEmploye),
    path('deleteemploye/<int:id>', views.DeleteEmploye),
    path('editemploye/<int:id>', views.EditEmploye),
    path('updateemploye/<int:id>', views.UpdateEmploye),

    path('addbagtype', views.AddBagType),
    path('viewbagtype', views.ViewBagType),
    path('deletebagtype/<int:id>', views.DeleteBagType),
    path('editbagtype/<int:id>', views.EditBagType),
    path('updatebagtype/<int:id>', views.UpdateBagType),

    path('addordermemo', views.AddOrderMemo),
    path('viewordermemo', views.ViewOrderMemo),
    path('deleteordermemo/<int:id>', views.DeleteOrderMemo),
    path('editordermemo/<int:id>', views.EditOrderMemo),
    path('updateordermemo/<int:id>', views.UpdateOrderMemo),
    path('addordermemo/ajax/load-customers/', views.load_customers, name='ajax_load_customers'), # AJAX

    path('addcashmemo', views.AddCashMemo),
    path('viewcashmemo', views.ViewCashMemo),
    path('deletecashmemo/<int:id>', views.DeleteCashMemo),
    path('editcashmemo/<int:id>', views.EditCashMemo),
    path('updatecashmemo/<int:id>', views.UpdateCashMemo),

    path('addsalary', views.AddSalary),
    path('viewsalary', views.ViewSalary),
    path('deletesalary/<int:id>', views.DeleteSalary),
    path('editsalary/<int:id>', views.EditSalary),
    path('updatesalary/<int:id>', views.UpdateSalary),

    path('addcost', views.AddCost),
    path('viewcost', views.ViewCost),
    path('deletecost/<int:id>', views.DeleteCost),
    path('editcost/<int:id>', views.EditCost),
    path('updatecost/<int:id>', views.UpdateCost),

    path('addinvestmentrefarence', views.AddInvestmentRefarence),
    path('viewinvestmentrefarence', views.ViewInvestmentRefarence),
    path('deleteinvestmentrefarence/<int:id>', views.DeleteInvestmentRefarence),
    path('editinvestmentrefarence/<int:id>', views.EditInvestmentRefarence),
    path('updateinvestmentrefarence/<int:id>', views.UpdateInvestmentRefarence),

    path('addinvestment', views.AddInvestment),
    path('viewinvestment', views.ViewInvestment),
    path('deleteinvestment/<int:id>', views.DeleteInvestment),
    path('editinvestment/<int:id>', views.EditInvestment),
    path('updateinvestment/<int:id>', views.UpdateInvestment),

    path('addstock', views.AddStock),
    path('viewstock', views.ViewStock),
    path('deletestock/<int:id>', views.DeleteStock),
    path('editstock/<int:id>', views.EditStock),
    path('updatestock/<int:id>', views.UpdateStock),

    path('addstockprice', views.AddStockPrice),
    path('viewstockprice', views.ViewStockPrice),
    path('deletestockprice/<int:id>', views.DeleteStockPrice),
    path('editstockprice/<int:id>', views.EditStockPrice),
    path('updatestockprice/<int:id>', views.UpdateStockPrice),

    path('addcatagory', views.AddCatagory),
    path('viewcatagory', views.ViewCatagory),
    path('deletecatagory/<int:id>', views.DeleteCatagory),
    path('editcatagory/<int:id>', views.EditCatagory),
    path('updatecatagory/<int:id>', views.UpdateCatagory),

    path('addbuy', views.AddBuy),
    path('viewbuy', views.ViewBuy),
    path('deletebuy/<int:id>', views.DeleteBuy),
    path('editbuy/<int:id>', views.EditBuy),
    path('updatebuy/<int:id>', views.UpdateBuy),
    

    
    path('viewtotal', views.ViewTotal),
    path('analysis', views.Analysis),
    path('index', views.index, name='index'),
    
    path('member/ajax/load-cities/', views.load_cities, name='ajax_load_cities'), # AJAX
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
handler404 = 'masumabaghouse.views.error_404_view'
